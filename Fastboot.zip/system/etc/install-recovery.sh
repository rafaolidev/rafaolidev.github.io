#!/system/bin/sh
#Please don't edit this if you don't know what are you doing

/system/bin/runinit

###################
#noobpremium@xda
###################